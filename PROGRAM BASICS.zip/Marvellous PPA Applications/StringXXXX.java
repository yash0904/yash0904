import java.io.*;

class StringXXXX
{
    public static void main(String a[])
    {
        String str1 = new String("Hello");
        StringBuffer str2 = new StringBuffer("Hello");
        StringBuilder str3 = new StringBuilder("Hello");

        System.out.println(str1);
        System.out.println(str1.length());

        System.out.println(str2);
        System.out.println(str2.length());

        System.out.println(str3);
        System.out.println(str3.length());

    }
}