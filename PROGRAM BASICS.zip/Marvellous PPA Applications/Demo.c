#include<stdio.h>

int main()
{
    printf("Jay Ganesh...\n");

    return 0;
}

// return 0         Succesfull termination
// return 1         Abnormal termination
// return -1        Erronious termination
























int no = 11;





int *p = &no;








