// Demo.java





import      java.lang.*     ;



class       Demo
{

        public          static              void            main(String         arg[])
        {


            System.     out.        println      ("Jay Ganesh...");


        }
}



//      javac Demo.java
//      java Demo               /       java  Demo.class            /      java Demo.java