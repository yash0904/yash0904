#include<iostream>
using namespace std;

class Demo
{
    public:
        int i,j;

        void fun()      // Defination
        {
            cout<<"Inside fun\n";
        }
        void gun()  // Defination
        {
            cout<<"Inside gun\n";
        }
};

int main()
{
    return 0;
}