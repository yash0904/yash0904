#include<stdio.h>

int main()
{

    int no1 = 10;
    int no2 = 10;

    no1++;  // no1 = no1 + 1
    ++no2;  // no2 = no2 + 1



    printf("Value of no1 %d\n",no1);
    printf("Value of no2 %d\n",no2);

    return 0;
}
